
package com.example.sijil;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.print.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int NAVY=Color.rgb(6,26,51), BLUE=Color.rgb(13,93,184), GOLD=Color.rgb(201,162,39);
    static final int LIGHT=Color.rgb(244,247,251), TEXT=Color.rgb(22,34,53), GREEN=Color.rgb(27,154,89), RED=Color.rgb(216,58,58);
    ArrayList<Student> students=new ArrayList<>();
    LinearLayout root, content;
    TextView title;
    int currentSection=1;
    final String PREF="grades_db";

    @Override public void onCreate(Bundle b){
        super.onCreate(b); load(); showDashboard();
    }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);
        t.setPadding(dp(12),dp(8),dp(12),dp(8)); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t;
    }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(round(BLUE,dp(12))); return b; }
    GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(17);e.setTextColor(TEXT);e.setHintTextColor(Color.GRAY);
        e.setGravity(Gravity.RIGHT);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(round(Color.WHITE,dp(10)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(55));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    void base(String page){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(LIGHT); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(8),0,dp(8),0);bar.setBackgroundColor(NAVY);
        Button back=btn("‹");back.setTextSize(30);back.setContentDescription("رجوع");back.setBackgroundColor(Color.TRANSPARENT);
        bar.addView(back,new LinearLayout.LayoutParams(dp(55),dp(60))); back.setOnClickListener(v->showDashboard());
        title=tv(page,20,Color.WHITE,true);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(60),1));
        root.addView(bar);
        ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),dp(14),dp(14),dp(24));sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void add( View v){content.addView(v);}
    TextView heading(String s){TextView h=tv(s,21,NAVY,true);h.setPadding(dp(8),dp(15),dp(8),dp(8));return h;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(round(Color.WHITE,dp(16)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(6),0,dp(6));c.setLayoutParams(p);return c;}

    void showDashboard(){
        base("سجل درجات الاجتماعيات");
        TextView brand=tv("للأستاذ أمير محمد",17,GOLD,true);brand.setGravity(Gravity.CENTER);add(brand);
        LinearLayout summary=card(); TextView s=tv("إجمالي الطلاب\n"+students.size()+" / 200",24,NAVY,true);s.setGravity(Gravity.CENTER);summary.addView(s);add(summary);
        add(heading("الشُعَب الدراسية"));
        for(int i=1;i<=4;i++){final int sec=i; LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);
            TextView x=tv("الشعبة "+i+"\n"+count(sec)+" طالب",18,TEXT,true);x.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            c.addView(x,new LinearLayout.LayoutParams(0,dp(78),1));Button b=btn("فتح");c.addView(b,new LinearLayout.LayoutParams(dp(90),dp(58)));b.setOnClickListener(v->showStudents(sec));add(c);}
        add(heading("الإدارة والتقارير"));
        Button manage=btn("👥  إدارة الطلاب"); add(manage); manage.setOnClickListener(v->showStudents(currentSection));
        Button stats=btn("📊  الإحصائيات العامة"); add(stats); stats.setOnClickListener(v->showStats());
        Button report=btn("🖨  التقارير والطباعة"); add(report); report.setOnClickListener(v->showReports());
        Button backup=btn("💾  نسخ احتياطي واستعادة"); add(backup); backup.setOnClickListener(v->backupInfo());
    }

    int count(int sec){int n=0;for(Student s:students)if(s.section==sec)n++;return n;}
    ArrayList<Student> sectionList(int sec){ArrayList<Student>a=new ArrayList<>();for(Student s:students)if(s.section==sec)a.add(s);return a;}

    void showStudents(int sec){
        currentSection=sec;base("الشعبة "+sec+" — الطلاب");
        EditText search=input("🔎  ابحث باسم الطالب");add(search);
        Button addb=btn("＋  إضافة طالب جديد");add(addb);addb.setOnClickListener(v->editStudent(null,sec));
        LinearLayout list=card();add(list);
        Runnable refresh=()->{
            list.removeAllViews();String q=search.getText().toString().trim();
            for(Student st:sectionList(sec))if(q.isEmpty()||st.name.contains(q)){LinearLayout row=card();row.setOrientation(LinearLayout.HORIZONTAL);
                TextView n=tv(st.name+"\nالمعدل: "+fmt(st.overall())+"   •   "+status(st.overall()),16,TEXT,true);
                row.addView(n,new LinearLayout.LayoutParams(0,dp(78),1));Button e=btn("تعديل");row.addView(e,new LinearLayout.LayoutParams(dp(85),dp(58)));
                e.setOnClickListener(v->editStudent(st,sec));list.addView(row);}
            if(list.getChildCount()==0)list.addView(tv("لا يوجد طلاب في هذه الشعبة.",17,Color.GRAY,false));
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});
        refresh.run();
    }

    void editStudent(Student st,int sec){
        base(st==null?"إضافة طالب":"تعديل الطالب");
        EditText name=input("اسم الطالب"); if(st!=null)name.setText(st.name);add(name);
        if(st==null){
            Button save=btn("حفظ الطالب");add(save);save.setOnClickListener(v->{String n=name.getText().toString().trim();if(n.isEmpty()){toast("اكتب اسم الطالب");return;}if(count(sec)>=50){toast("الشعبة مكتملة: 50 طالب");return;}Student x=new Student();x.name=n;x.section=sec;students.add(x);save();showStudents(sec);});
        }else{
            add(heading("درجات الطالب"));
            addGradeFields(st);
            Button saveb=btn("💾 حفظ التعديلات");add(saveb);saveb.setOnClickListener(v->{st.name=name.getText().toString().trim();save();showStudents(sec);});
            Button del=btn("🗑 حذف الطالب");del.setBackground(round(RED,dp(12)));add(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الطالب").setMessage("هل تريد حذف "+st.name+"؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{students.remove(st);save();showStudents(sec);}).show());
        }
    }

    void addGradeFields(Student st){
        for(int term=0;term<2;term++){
            add(heading(term==0?"الفصل الأول":"الفصل الثاني"));
            for(int month=0;month<2;month++){
                add(tv(month==0?"الشهر الأول":"الشهر الثاني",18,BLUE,true));
                String[] labels={"اليومي 1","اليومي 2","اليومي 3","النشاط","السلوك","الدفتر"};
                for(int i=0;i<6;i++){EditText e=input(labels[i]+" (من 20)");double v=st.g[term][month][i];if(v>=0)e.setText(fmt(v));add(e);
                    final int t=term,m=month,k=i;e.setTag("g_"+t+"_"+m+"_"+k);e.setOnFocusChangeListener((v,f)->{if(!f){Double x=num(e.getText().toString());if(x==null||x<0||x>20){toast("الدرجة يجب أن تكون بين 0 و20");e.requestFocus();}else st.g[t][m][k]=x;}});}
                add(tv("المعدل الشهري المحسوب: "+fmt(st.monthAvg(term,month))+" / 50",15,NAVY,true));
            }
            add(tv("معدل الفصل: "+fmt(st.termAvg(term))+" / 50",17,GREEN,true));
        }
        EditText half=input("نصف السنة (اختياري، من 100)");half.setText(st.half>=0?fmt(st.half):"");add(half);
        EditText annual=input("السعي السنوي (اختياري، من 100)");annual.setText(st.annual>=0?fmt(st.annual):"");add(annual);
        Button saveGrades=btn("تحديث الدرجات المحسوبة");add(saveGrades);saveGrades.setOnClickListener(v->{for(int t=0;t<2;t++)for(int m=0;m<2;m++)for(int k=0;k<6;k++){View q=content.findViewWithTag("g_"+t+"_"+m+"_"+k);if(q instanceof EditText){Double x=num(((EditText)q).getText().toString());if(x!=null&&x>=0&&x<=20)st.g[t][m][k]=x;}}
            st.half=num(half.getText().toString());if(st.half==null)st.half=-1;st.annual=num(annual.getText().toString());if(st.annual==null)st.annual=-1;save();toast("تم حفظ الدرجات");});
    }

    Double num(String s){try{return s==null||s.trim().isEmpty()?null:Double.parseDouble(s.trim());}catch(Exception e){return null;}}
    String fmt(double d){return String.format(Locale.US,"%.1f",d).replace(".0","");}
    String status(double a){return a>=25?"ناجح":"دون النجاح";}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void showStats(){
        base("الإحصائيات العامة");int pass=0;double sum=0;for(Student s:students){double a=s.overall();sum+=a;if(a>=25)pass++;}
        add(heading("ملخص الدرجات"));
        add(stat("إجمالي الطلاب",students.size()+""));
        add(stat("الناجحون",pass+""));
        add(stat("دون النجاح",(students.size()-pass)+""));
        add(stat("متوسط جميع الطلاب",students.isEmpty()?"0":fmt(sum/students.size())));
        for(int i=1;i<=4;i++)add(stat("الشعبة "+i,count(i)+" طالب"));
    }
    TextView stat(String a,String b){TextView t=tv(a+"     "+b,18,TEXT,true);t.setBackground(round(Color.WHITE,dp(12)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(58));p.setMargins(0,dp(5),0,dp(5));t.setLayoutParams(p);return t;}

    void showReports(){
        base("التقارير والطباعة");
        add(heading("اختر الشعبة"));
        for(int i=1;i<=4;i++){final int sec=i;Button b=btn("🖨  طباعة تقرير الشعبة "+i+"  ("+count(i)+" طالب)");add(b);b.setOnClickListener(v->printSection(sec));}
        add(heading("ملاحظة"));add(tv("التقرير مصمم ليكون واضحاً للطباعة، ويعرض درجات اليومي 1 و2 و3 والنشاط والدفتر والسلوك مع معدلات الأشهر والفصول.",16,TEXT,false));
    }

    void printSection(int sec){
        StringBuilder h=new StringBuilder();
        h.append("<html dir='rtl'><head><meta charset='utf-8'><style>")
         .append("body{font-family:sans-serif;margin:18px}h1,h2{text-align:center;color:#061A33}")
         .append("table{border-collapse:collapse;width:100%;font-size:10px}th,td{border:1px solid #777;padding:4px;text-align:center}th{background:#061A33;color:white} .gold{color:#C9A227}")
         .append("</style></head><body><h1>سجل درجات الاجتماعيات</h1><h2>للأستاذ أمير محمد — الشعبة ").append(sec).append("</h2>")
         .append("<table><tr><th>ت</th><th>اسم الطالب</th><th>ش1<br>ي1</th><th>ي2</th><th>ي3</th><th>نشاط</th><th>دفتر</th><th>سلوك</th><th>ش2<br>ي1</th><th>ي2</th><th>ي3</th><th>نشاط</th><th>دفتر</th><th>سلوك</th><th>ف1</th><th>ف2</th><th>نصف السنة</th><th>السعي السنوي</th></tr>");
        int i=1;for(Student s:sectionList(sec)){h.append("<tr><td>").append(i++).append("</td><td>").append(esc(s.name)).append("</td>");
            for(int k:new int[]{0,1,2,3,5,4})h.append("<td>").append(fmt(s.g[0][0][k])).append("</td>");
            for(int k:new int[]{0,1,2,3,5,4})h.append("<td>").append(fmt(s.g[0][1][k])).append("</td>");
            h.append("<td>").append(fmt(s.termAvg(0))).append("</td><td>").append(fmt(s.termAvg(1))).append("</td><td>").append(s.half<0?"":fmt(s.half)).append("</td><td>").append(s.annual<0?"":fmt(s.annual)).append("</td></tr>");}
        h.append("</table></body></html>");
        WebView w=new WebView(this);w.getSettings().setDefaultTextEncodingName("utf-8");w.loadDataWithBaseURL(null,h.toString(),"text/html","UTF-8",null);
        w.setWebViewClient(new android.webkit.WebViewClient(){public void onPageFinished(WebView v,String u){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("تقرير الشعبة "+sec,v.createPrintDocumentAdapter("تقرير الشعبة "+sec),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());}});
    }
    String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}
    void backupInfo(){new AlertDialog.Builder(this).setTitle("النسخ الاحتياطي").setMessage("البيانات محفوظة محلياً داخل الهاتف. في النسخة التالية يمكن إضافة تصدير واستيراد ملف احتياطي كامل.").setPositiveButton("حسناً",null).show();}

    void save(){getPreferences(0).edit().putString(PREF,toJson()).apply();}
    void load(){String x=getPreferences(0).getString(PREF,"");if(x.isEmpty())return;try{JSONArray a=new JSONArray(x);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Student s=new Student();s.name=o.optString("name");s.section=o.optInt("section",1);s.half=o.optDouble("half",-1);s.annual=o.optDouble("annual",-1);JSONArray terms=o.optJSONArray("g");if(terms!=null)for(int t=0;t<2;t++)for(int m=0;m<2;m++)for(int k=0;k<6;k++)s.g[t][m][k]=terms.getJSONArray(t).getJSONArray(m).optDouble(k,0);students.add(s);}}catch(Exception ignored){}}
    String toJson(){JSONArray a=new JSONArray();try{for(Student s:students){JSONObject o=new JSONObject();o.put("name",s.name);o.put("section",s.section);o.put("half",s.half);o.put("annual",s.annual);JSONArray ts=new JSONArray();for(int t=0;t<2;t++){JSONArray ms=new JSONArray();for(int m=0;m<2;m++){JSONArray gs=new JSONArray();for(int k=0;k<6;k++)gs.put(s.g[t][m][k]);ms.put(gs);}ts.put(ms);}o.put("g",ts);a.put(o);}}catch(Exception ignored){}return a.toString();}

    static class Student{
        String name="";int section=1;double half=-1,annual=-1;double[][][] g=new double[2][2][6];
        Student(){for(int t=0;t<2;t++)for(int m=0;m<2;m++)for(int k=0;k<6;k++)g[t][m][k]=0;}
        double monthAvg(int t,int m){return (g[t][m][0]+g[t][m][1]+g[t][m][2]+g[t][m][3]+g[t][m][5])/2.0;}
        double termAvg(int t){return (monthAvg(t,0)+monthAvg(t,1))/2.0;}
        double overall(){return (termAvg(0)+termAvg(1))/2.0;}
    }
}
